package org.yolo.holo.dao;

import org.apache.ibatis.session.SqlSession;
import org.yolo.holo.util.SqlSessionUtil;
	
public class DounorSavesDAO {
	
		public static int selectSpotLike(int no) {
			
			int like = 0;
			
			SqlSession session = null;
			
			try {
				session = SqlSessionUtil.getSession();
				
				like = session.selectOne("dounorsave.selectSpotLike",no);
				
			} catch (Exception e) {
				e.printStackTrace();
			}finally {
				session.close();
			}//try~catch~finally end
			
			return like;
		}//selectSpotLike end
		
public static int selectSpotScrap(int no) {
			
			int scrap = 0;
			
			SqlSession session = null;
			
			try {
				session = SqlSessionUtil.getSession();
				
				scrap = session.selectOne("dounorsave.selectSpotScrap",no);
				
			} catch (Exception e) {
				e.printStackTrace();
			}finally {
				session.close();
			}//try~catch~finally end
			
			return scrap;
		}//selectSpotScrap end
	
}
